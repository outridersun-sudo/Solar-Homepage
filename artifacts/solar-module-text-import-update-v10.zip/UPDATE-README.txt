Solar Homepage v10 — 확정된 28개 열 텍스트 붙여넣기 등록

적용: v5+v6 또는 v7~v9 적용 상태에 저장소 루트 경로 그대로 덮어쓰는 누적 수정 ZIP입니다.
새 npm 의존성은 없습니다. .env, 기존 업로드·카탈로그·node_modules는 포함하지 않으며 덮어쓰지 않습니다.
적용 전에 교체 대상 소스를 백업하고 적용 후 Node.js 서버를 재시작하세요.
Windows PowerShell에서 npm.ps1이 차단되면 npm.cmd start 를 사용하세요.

사용법:
1. GPT가 출력한 헤더 포함 28개 열 TSV를 한 번에 붙여넣습니다.
2. 모델별 검토표 만들기 -> 수치·조건·출처를 원본과 확인합니다.
3. 셀을 직접 수정한 경우 수정값 검사를 누릅니다.
4. 등록할 정상 모델 선택 -> 원본 대조 완료와 양면 방식 동의 -> 선택한 모델 등록.
5. 계산기를 새로고침해 등록한 모델을 선택합니다.

텍스트 등록에는 Tesseract·Poppler·PDF 업로드가 필요 없습니다.
기존 PDF/이미지 분석은 접힌 선택 메뉴로 유지하며 해당 메뉴에만 기존 OCR 준비가 필요합니다.
검토표 작성이나 검사만으로는 저장되지 않습니다. 기존 모델을 덮어쓰지 않습니다.
선택 자료는 서버에서 재검사하며 오류·중복이 있으면 요청 전체를 저장하지 않습니다.
한 번에 1~50개 모델, UTF-8 80KB까지 지원합니다.

계산 규칙:
- bnpi: 기존 기준 후면 13.5%와 설계 모드에 따라 STC-BNPI 보정. 기존 동작 유지.
- gain10: 제조사 발전 증가율 10% 표의 원본 양면 사양 고정.
- bstc: 제조사 BSTC 표의 원본 양면 사양 고정.
- 고정 모드는 후면 일사율 입력을 사용하지 않고 발전 증가율·양면계수를 추가로 곱하지 않습니다.
- 온도·전압 여유·전류 보정은 유지합니다. 설비 DC 용량과 모듈 수량 기준은 STC 출력입니다.
- 고정 모드의 Voc도 원본 양면 값으로 사용합니다. 이전 gain10 자료 재현 모드의 STC Voc 대입과 달라집니다.

28개 셀, 파일명·페이지·원본 시험 조건·출력 기준 양면계수·계산 참고값을 보존합니다.
파일명은 사용자가 제공한 출처이며 실제 PDF가 업로드되었다는 뜻은 아닙니다.
검토 완료와 동의는 붙여넣은 텍스트가 아니라 사용자가 화면에서 직접 확인합니다.

예제: examples 폴더의 한솔(BSTC 6개), 에스에너지(BNPI 6개), Canadian Solar(gain10 7개) TSV.
에스에너지 예제는 사용자 제공 추출 자료이며 실제 등록 전 원본 PDF 대조가 필요합니다.
예제는 자동 등록하지 않습니다. 세부 설명과 제약은 docs/module-text-import.md를 확인하세요.

검증:
node --test --test-isolation=none test/module-text-import.test.js
node test/module-text-import-ui.cjs
node --test --test-isolation=none test/calculator.test.js
node test/calculator-ui.cjs
node --test --test-isolation=none test/module-review.test.js
node test/module-pdf-ocr-ui.cjs
node test/module-review-ui.cjs
브라우저 검증은 환경 제공 Playwright 및 /usr/bin/chromium을 사용합니다.
기존 계산기 UI 테스트에는 3000 포트가 비어 있어야 합니다. 테스트는 임시 데이터만 사용합니다.
19개 모델 일괄 검사·저장, 실제 클립보드 붙여넣기와 수정/동의/중복/모바일,
BNPI 보정 및 BSTC/gain10 고정 적용·계산 워커·기존 계산기와 PDF/이미지 흐름을 검증했습니다.

원복은 백업 소스를 복원하고 서버를 재시작합니다. 사용자가 등록한 데이터는 삭제하지 마세요.
SHA256SUMS.txt로 압축 내 파일 무결성을 확인할 수 있습니다.
