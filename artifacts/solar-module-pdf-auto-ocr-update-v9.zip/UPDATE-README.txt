Solar Homepage v9 — PDF 단독 자동 OCR 분석

적용: v5 + v6 또는 v7/v8 적용 상태에 저장소 루트 경로대로 덮어쓰는 누적 수정 ZIP입니다.
.env, 사용자 업로드, catalog.json 및 node_modules는 포함하지 않습니다. 적용 전 교체 파일을 백업하세요.

변경 사항:
- PDF 텍스트를 먼저 분석합니다. 필수 사양이 부족하면 선택한 PDF 페이지 이미지에 자동 OCR을 실행합니다.
- 스캔 PDF에서도 모델과 사양표가 인식되면 필수 항목을 채웁니다. 별도 이미지 붙여넣기는 선택입니다.
- 값마다 PDF / PDF 1페이지 OCR / 이미지 1 OCR 등의 출처를 표시합니다.
- 텍스트에서 이미 읽힌 값은 유지하고 OCR 누락값을 보완합니다. 값 충돌은 경고합니다.
- 같은 업로드/페이지의 OCR 결과는 재사용합니다. 필수값이 완전한 텍스트 PDF는 OCR을 실행하지 않습니다.
- OCR이 준비되지 않았거나 페이지 OCR이 실패해도 PDF 텍스트와 미리보기는 유지하고 안내합니다.
- OCR 값은 원본 근거와 검토 확인 후 등록합니다. 직접 수정도 가능합니다.

서버 준비:
Tesseract 5와 한국어/영어 모델을 이미 준비했다면 ZIP 적용 후 기존 방식으로 서버를 재시작하면 됩니다.
아직 준비하지 않았다면 저장소 루트에서 node scripts/setup-module-ocr.js 를 실행하세요.
프로그램 자체 설치는 별도이며 Windows에서는 UB Mannheim Tesseract 설치 프로그램을 사용하세요.
Windows .env 예시 (실제 설치 위치에 맞게 지정):
MODULE_TESSERACT_BIN="C:/Program Files/Tesseract-OCR/tesseract.exe"
설치 스크립트도 이제 .env의 경로를 읽습니다. 모델은 .cache/solar-ocr에 고정 체크섬을 검증해 준비합니다.
Linux에서 프로그램이 없으면 sudo apt-get install -y tesseract-ocr curl 로 설치할 수 있습니다.
기존 PDF 도구(Poppler)는 그대로 사용합니다.

사용법:
PDF 선택 -> 사양표 페이지 지정 -> PDF 분석 · 보완 이미지 함께 적용 -> 자동 입력값 확인 -> 원본 검토 후 등록.
PDF에 없는 자료만 선택적으로 복사/붙여넣어 보완하세요. 한 번에 선택한 PDF 한 페이지를 분석합니다.
읽지 못한 값이나 모델을 구분하기 어려운 표의 값은 직접 확인이 필요합니다.

검증 명령 (Node.js 24 / Poppler / Tesseract 및 kor/eng 모델):
node --test --test-isolation=none test/module-image-ocr.test.js test/module-pdf-ocr.test.js
node --test --test-isolation=none test/module-review.test.js
node test/module-pdf-ocr-ui.cjs
node test/module-review-ui.cjs
node --test --test-isolation=none test/calculator.test.js
node test/calculator-ui.cjs
UI 테스트는 환경 제공 Playwright와 Chromium을 사용하며 마지막 계산기 테스트는 3000 포트가 비어 있어야 합니다.
실제 스캔 PDF/혼합 PDF OCR, PDF만으로 브라우저 등록·저장, 보완 이미지 클립보드, 캐시/누락 도구/충돌/기존 계산기를 검증했습니다.

원복: 백업 파일을 복원하고 서버를 재시작하세요. 사용자 업로드나 카탈로그는 삭제하지 마세요.
SHA256SUMS.txt로 압축 안 파일들의 무결성을 확인할 수 있습니다.
