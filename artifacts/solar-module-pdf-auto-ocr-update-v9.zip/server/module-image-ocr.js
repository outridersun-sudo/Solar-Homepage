'use strict';
const {execFile}=require('node:child_process');
const {promisify}=require('node:util');
const fs=require('node:fs');
const path=require('node:path');
const run=promisify(execFile);
const parser=require('./module-pdf-parser');
const {numeric}=require('./module-catalog');
const sharedKeys=new Set(['maxV','betaVoc','alphaIsc','gammaPower','maxSeriesFuse']);
const identity=value=>String(value || '').normalize('NFKC').toLowerCase().replace(/\s+/g,'');
async function recognize(filename, options={}){
 const local=path.resolve(__dirname,'../.cache/solar-ocr');
 const directory=process.env.MODULE_OCR_DATA_DIR || (fs.existsSync(path.join(local,'kor.traineddata'))?local:null);
 const args=[filename,'stdout','-l','kor+eng','--psm',String(options.psm || 6),'-c','preserve_interword_spaces=1'];
 if(directory)args.push('--tessdata-dir',directory);
 try{
  const result=await run(process.env.MODULE_TESSERACT_BIN || 'tesseract',args,{timeout:25000,maxBuffer:512*1024,env:{...process.env,OMP_THREAD_LIMIT:'1'}});
  return result.stdout.slice(0,60000);
 }catch(error){
  if(error.code==='ENOENT' || /traineddata|Failed loading language|Error opening data file/.test(error.stderr || ''))throw Object.assign(new Error('이미지 OCR 준비가 필요합니다. Tesseract 설치 후 node scripts/setup-module-ocr.js를 실행하세요.'),{status:503});
  throw Object.assign(new Error(options.pdfPage?'PDF 페이지 OCR에 실패했습니다. 다른 사양표 페이지를 선택하거나 보완 이미지를 붙여넣으세요.':'붙여넣은 이미지를 읽지 못했습니다. 이미지를 제거하고 더 선명한 표를 다시 복사하세요.'),{status:422});
 }
}
function imageAnalysis(raw){
 const text=parser.normalize(raw).replace(/([+-])\s+(?=\d)/g,'$1');
 const result=parser.analyze(text),fields={...result.fields};
 // Some datasheets put the word "temperature" in a heading and symbols in rows.
 const coefficients={betaVoc:'Voc',alphaIsc:'Isc',gammaPower:'Pmax|PMPP'};
 if(/temperature|온도/i.test(text))for(const [key,symbol]of Object.entries(coefficients)){
  const values=[];
  for(const line of text.split('\n')){
   if(!new RegExp('\\b(?:'+symbol+')\\b','i').test(line) || !/%/.test(line))continue;
   const matches=[...line.matchAll(/([+-]?(?:\d+\.?\d*|\.\d+))\s*%/g)].map(match=>Number(match[1]));
   if(matches.length===1 && matches[0]>=numeric[key][0] && matches[0]<=numeric[key][1])values.push(matches[0]);
  }
  if(values.length && new Set(values).size===1)fields[key]=values[0];
 }
 const rear=text.split(/\bBNPI\b/i)[1];
 if(rear)Object.assign(fields,parser.bnpiFields(parser.columnFields(parser.rowsFrom(rear,1),0)));
 return {...result,fields,text};
}
function combine(base,images){
 const result=structuredClone(base),warnings=[],conflicts=[];
 const supplements=images.map((image,index)=>({...image,analysis:imageAnalysis(image.text || ''),source:image.source || '이미지 '+(index+1)+' OCR'}));
 const merge=(fields,modelName,multiple,existingSources={})=>{
  const output={...fields},sources=Object.fromEntries(Object.keys(fields).map(key=>[key,existingSources[key] || 'PDF'])),proposals=new Map();
  for(const image of supplements){
   const parsed=image.analysis;
   const candidate=parsed.models.find(model=>identity(model.fields.name)===identity(modelName)) || (modelName && parsed.fields.name && identity(parsed.fields.name)===identity(modelName)?{fields:parsed.fields}:null);
   // Never apply another model's table or unnamed electrical rows across models.
   if((parsed.models.length || parsed.fields.name) && modelName && !candidate){warnings.push(image.source+': PDF 모델과 일치하지 않아 자동 적용하지 않았습니다.');continue;}
   if(multiple && !modelName && (parsed.models.length || parsed.fields.name))continue;
   const extra=candidate?.fields || parsed.fields;
   for(const [key,value]of Object.entries(extra)){
    if(['manufacturer','series','name'].includes(key) && !multiple && !modelName && !output[key] && typeof value==='string'){
      const values=proposals.get(key)||[];values.push({value,source:image.source});proposals.set(key,values);continue;
    }
    if(!Object.hasOwn(numeric,key) || (multiple && !candidate && !sharedKeys.has(key)))continue;
    const [min,max]=numeric[key];if(!Number.isFinite(value)||value<min||value>max)continue;
    if(Object.hasOwn(output,key)){
     if(output[key]!==value)conflicts.push(key+' — PDF와 '+image.source+' 값이 다릅니다. 원본을 확인하세요.');
     continue;
    }
    const values=proposals.get(key)||[];values.push({value,source:image.source});proposals.set(key,values);
   }
  }
  for(const [key,values]of proposals){
   if(new Set(values.map(item=>item.value)).size!==1){conflicts.push(key+' — 이미지 간 값이 달라 직접 확인이 필요합니다.');continue;}
   output[key]=values[0].value;sources[key]=values.map(item=>item.source).join(', ');
  }
  return {fields:output,fieldSources:sources};
 };
 const multiple=result.models.length>1;
 for(const model of result.models){
  Object.assign(model,merge(model.fields,model.fields.name,multiple,model.fieldSources));
  if(['bnpi','bnpiVoc','bnpiVmp','bnpiIsc','bnpiImp'].every(key=>Number.isFinite(model.fields[key])))model.suggestedRearMode='bnpi';
  // OCR rear conditions require explicit review; never invent a new automatic policy.
  if(supplements.length)model.warnings=[...(model.warnings || []),'OCR 보완값을 원본과 대조하세요. 누락된 양면 기준은 직접 검토 후 등록하세요.'];
 }
 Object.assign(result,result.models.length===1?{fields:result.models[0].fields,fieldSources:result.models[0].fieldSources}:merge(result.fields,'',multiple,result.fieldSources));
 for(const image of supplements)if(!image.text?.trim())warnings.push(image.source+': 읽을 수 있는 텍스트가 없습니다.');
 result.imageTexts=[...(base.imageTexts || []),...supplements.filter(image=>!image.pdfPage).map(image=>({filename:image.filename,text:image.text}))];
 result.ocrUsed=!!base.ocrUsed || supplements.length>0;
 const pdfImage=supplements.find(image=>image.pdfPage);
 if(pdfImage)result.pdfOcrText=pdfImage.text;
 result.conflicts=[...new Set([...(base.conflicts || []),...conflicts])];
 result.warning=[result.warning,...new Set(warnings),...result.conflicts].filter(Boolean).join('\n');
 result.method=result.pdfOcrText!==undefined?(result.imageTexts.length?'pdf+ocr+image-ocr':'pdf+ocr'):(result.imageTexts.length?'pdf+image-ocr':base.method);
 return result;
}
function complete(analysis){
 return analysis.models.length>0 && analysis.models.every(model=>Object.keys(numeric).every(key=>Number.isFinite(model.fields[key]) || Number.isFinite(model.substitute10?.[key])));
}
function combinePdf(base,text){
 const parsed=imageAnalysis(text),source='PDF '+base.page+'페이지 OCR';
 let seed=base;
 if(!base.models.length && parsed.models.length){
  const multiple=parsed.models.length>1;
  const shared=multiple?Object.fromEntries(Object.entries(base.fields).filter(([key])=>sharedKeys.has(key))):base.fields;
  const models=parsed.models.map(model=>{
   const fields={...model.fields,...shared};
   return {...model,fields,fieldSources:Object.fromEntries(Object.keys(fields).map(key=>[key,Object.hasOwn(shared,key)?'PDF':source]))};
  });
  seed={...base,profile:parsed.profile,models};
 }
 return combine(seed,[{filename:'PDF '+base.page+'페이지',text,source,pdfPage:true}]);
}
module.exports={recognize,imageAnalysis,combine,combinePdf,complete};
