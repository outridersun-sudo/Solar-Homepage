'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {promisify}=require('node:util');
const run=promisify(require('node:child_process').execFile);
const {textPDF,scannedPDF}=require('./helpers/module-fixtures.cjs');
const pdf=require('../server/module-pdf');
const rear=['BNPI','Rated power (Pmax) 700 W','Open circuit voltage (Voc) 50 V','Maximum power voltage (Vmp) 40 V','Short circuit current (Isc) 18.5 A','Maximum power current (Imp) 17.5 A'];
test('actual PDF-page OCR fallback, text priority, cache and missing-tool behavior',{timeout:120000},async t=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'solar-pdf-ocr-'));
 const previous=process.env.MODULE_TESSERACT_BIN;
 try{
  const original=path.join(dir,'text.pdf');await fs.writeFile(original,textPDF(rear));
  await run(pdf.renderCommand,['-singlefile','-scale-to-x','1600','-scale-to-y','2000','-jpeg',original,path.join(dir,'scan')]);
  const image=await fs.readFile(path.join(dir,'scan.jpg'));
  const scan=path.join(dir,'scan.pdf');await fs.writeFile(scan,scannedPDF(image));
  const cache=new Map();let scanned;
  await t.test('a scanned PDF alone recovers model and required specifications with OCR provenance',async()=>{
   scanned=await pdf.extract(scan,1,[],cache);
   assert.equal(scanned.text.trim(),'');assert.equal(scanned.pdfOcr.status,'completed');assert.equal(scanned.method,'pdf+ocr');assert.equal(scanned.models.length,1,scanned.pdfOcrText);
   for(const [key,value]of Object.entries({p:650,voc:50,vmp:40,isc:17,imp:16.25,maxV:1500,maxSeriesFuse:30,betaVoc:-.25,alphaIsc:.04,gammaPower:-.29,bnpi:700,bnpiImp:17.5})){
    assert.equal(scanned.fields[key],value,key+'\n'+scanned.pdfOcrText);assert.match(scanned.fieldSources[key],/PDF 1페이지 OCR/);
   }
   assert.equal(scanned.imageTexts.length,0);assert.equal(scanned.ocrUsed,true);
  });
  await t.test('re-analysis reuses page OCR cache even if the executable becomes unavailable',async()=>{
   process.env.MODULE_TESSERACT_BIN='/nonexistent/solar-test-tesseract';
   const cached=await pdf.extract(scan,1,[],cache);assert.equal(cached.pdfOcr.status,'completed');assert.deepEqual(cached.fields,scanned.fields);
  });
  await t.test('complete text PDF does not require or start OCR',async()=>{
   const complete=await pdf.extract(original,1);assert.equal(complete.pdfOcr.status,'not-needed');assert.equal(complete.method,'text');assert.equal(complete.fields.bnpi,700);
  });
  await t.test('missing OCR preserves readable PDF values and returns concrete setup instructions',async()=>{
   const missing=path.join(dir,'missing.pdf');await fs.writeFile(missing,textPDF());
   const result=await pdf.extract(missing,1);assert.equal(result.pdfOcr.status,'unavailable');assert.equal(result.fields.p,650);assert.match(result.warning,/setup-module-ocr/);assert.equal(result.ocrUsed,false);
  });
  if(previous===undefined)delete process.env.MODULE_TESSERACT_BIN;else process.env.MODULE_TESSERACT_BIN=previous;
  await t.test('hybrid PDF keeps text values while filling absent fields from its visible page',async()=>{
   const hybrid=path.join(dir,'hybrid.pdf');
   await fs.writeFile(hybrid,scannedPDF(image,1600,2000,['Manufacturer: Test Solar','Series: TEST Series','Model: TEST-650','STC','Rated power (Pmax) 651 W','Open circuit voltage (Voc) 50 V','Maximum power voltage (Vmp) 40 V','Short circuit current (Isc) 17 A','Maximum power current (Imp) 16.25 A']));
   const result=await pdf.extract(hybrid,1);assert.equal(result.fields.p,651);assert.equal(result.fieldSources.p,'PDF');assert.equal(result.fields.maxV,1500);assert.match(result.fieldSources.maxV,/PDF 1페이지 OCR/);assert.match(result.warning,/p —/);
  });
 }finally{if(previous===undefined)delete process.env.MODULE_TESSERACT_BIN;else process.env.MODULE_TESSERACT_BIN=previous;await fs.rm(dir,{recursive:true,force:true});}
});
