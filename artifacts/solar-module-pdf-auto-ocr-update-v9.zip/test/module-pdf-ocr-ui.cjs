'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const run=require('node:util').promisify(require('node:child_process').execFile);
const {chromium}=require('playwright');
const {textPDF,scannedPDF,testApp}=require('./helpers/module-fixtures.cjs');
(async()=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'solar-pdf-only-ui-'));process.env.MODULE_DATA_DIR=dir;
 const {app,password}=testApp();let browser;
 const server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s));});
 const base='http://127.0.0.1:'+server.address().port;
 try{
  const original=path.join(dir,'source.pdf');
  await fs.writeFile(original,textPDF(['BNPI','Rated power (Pmax) 700 W','Open circuit voltage (Voc) 50 V','Maximum power voltage (Vmp) 40 V','Short circuit current (Isc) 18.5 A','Maximum power current (Imp) 17.5 A']));
  await run(require('../server/module-pdf').renderCommand,['-singlefile','-scale-to-x','1600','-scale-to-y','2000','-jpeg',original,path.join(dir,'scan')]);
  const scan=scannedPDF(await fs.readFile(path.join(dir,'scan.jpg')));
  browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
  const page=await browser.newPage(),errors=[];page.on('pageerror',error=>errors.push(error.message));
  const login=await page.request.post(base+'/api/admin/login',{headers:{Origin:base},data:{username:process.env.ADMIN_USERNAME,password}});assert.equal(login.status(),200);
  await page.goto(base+'/reg-module.html');await page.waitForSelector('#management:visible');
  await page.setInputFiles('#pdf-file',{name:'scanned-spec.pdf',mimeType:'application/pdf',buffer:scan});
  await page.click('#analyze');await page.waitForSelector('#review:visible',{timeout:120000});await page.waitForFunction(()=>!document.querySelector('#analyze').disabled,null,{timeout:120000});
  assert.equal(await page.locator('#supplement-previews img').count(),0);
  for(const [id,value]of Object.entries({p:650,betaVoc:-.25,alphaIsc:.04,gammaPower:-.29,maxV:1500,maxSeriesFuse:30,bnpi:700,bnpiImp:17.5})){
   assert.equal(Number(await page.inputValue('#'+id)),value,id);assert.match(await page.locator('#'+id).locator('..').locator('..').innerText(),/PDF 1페이지 OCR/);
  }
  assert.equal(await page.locator('#manual-review').isChecked(),true);await page.locator('.preview-panel details summary').click();assert.match(await page.locator('#extracted-text').innerText(),/PDF 1페이지 OCR/);
  await page.fill('#evidence-text','PDF 1페이지의 STC 및 BNPI 원본 사양 대조 완료');await page.check('#review-confirmed');assert.equal(await page.locator('#save').isEnabled(),true);
  const response=page.waitForResponse(r=>r.url()===base+'/api/admin/modules' && r.request().method()==='POST');await page.click('#save');assert.equal((await response).status(),201);
  await page.waitForSelector('#review',{state:'hidden'});assert.deepEqual(errors,[]);
  const rows=JSON.parse(await fs.readFile(path.join(dir,'catalog.json'),'utf8'));assert.equal(rows[0].module.bnpi,700);assert.equal(rows[0].supplements.length,0);
  console.log('PASS: scanned PDF only, automatic page OCR, required-field autofill and source badges, review and persisted registration without supplementary images');
 }finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));await fs.rm(dir,{recursive:true,force:true});}
})().catch(error=>{console.error(error);process.exitCode=1;});
