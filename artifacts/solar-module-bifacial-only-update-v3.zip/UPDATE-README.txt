﻿태양광 모듈 등록 v3 — 양면 제품 전용 등록 제한 (OCR 없음)

앞서 설치한 태양광 모듈 등록 기능(v1/v2)에 적용하는 누적 업데이트입니다.
실행 중인 Node 서버를 Ctrl+C로 종료하고 기존 파일을 백업한 뒤 적용하세요.

[프로젝트 폴더에 추가/덮어쓸 파일]
server/module-pdf-parser.js (없으면 새로 추가)
server/module-pdf.js
server/module-catalog.js
server/modules.js
private/reg-module.html
public/js/reg-module.js
public/css/reg-module.css

[설명서]
docs/module-registration.md

폴더 구조를 그대로 유지하세요. reg-module.html은 private에 둡니다.
특히 server/modules.js를 포함해 모든 파일을 적용해야 서버 검증이 완성됩니다.
.env, 기존 모듈 JSON, uploads, package.json, package-lock.json은 변경하지 마세요.
새 npm 패키지나 OCR 설치는 필요 없습니다. 기존 Poppler는 유지하세요.

[적용 후]
같은 PowerShell 창에서 npm.cmd start로 서버를 실행합니다.
브라우저에서 Ctrl+F5로 새로고침하고 관리자 계정으로 다시 로그인합니다.

[변경사항]
1. 단면 모듈 STC 값 복사 버튼 제거.
2. 양면 제품 원본 확인 상태, 근거 PDF 페이지와 확인 문구 필수.
3. 실제 PDF 페이지 범위를 서버에서 검증.
4. 필수 STC/BNPI/온도계수/퓨즈 사양 미충족 시 등록 차단.
5. 단면 제품 / 양면 여부 미확인 / 양면 사양 부족으로 사유 구분.
6. BNPI 출력·전류는 STC보다 커야 하며 단면 값 그대로 복사 등록 차단.
7. 모델 변경 시 제품 확인 및 근거·검토 체크 초기화.
8. 근거 기록은 원본 PDF와 함께 저장되며 공개 계산기에는 노출되지 않음.

근거 문구는 관리자가 원본을 읽고 입력하는 기록입니다. 자동 진위 판정은 아닙니다.
확인하지 않은 제품을 양면으로 선택하거나 수치를 추정해 입력하지 마세요.
기존 현대·통웨이 등 등록 데이터는 수정/삭제/비활성화하지 않습니다.
새 등록에만 제한을 적용합니다. BNPI 없는 양면 제품도 추가 자료 확보 전 등록 불가입니다.
모델별 추출(19모델)과 OCR 제외 정책은 v2에서 유지합니다.

[검증]
파서 검사 6개, 인증/등록 API 검사 8개 통과.
브라우저 등록 화면 및 원본 Qcells PDF의 근거 입력/모델 전환/등록 검증 통과.
API 우회 요청의 단면/미확인/페이지 범위/사양 누락/STC 복사 차단도 확인했습니다.
