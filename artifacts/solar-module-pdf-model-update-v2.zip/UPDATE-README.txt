﻿태양광 모듈 PDF 모델별 자동 추출 개선 v2 (OCR 없음)

이 ZIP은 앞서 설치한 태양광 모듈 등록 기능에 적용하는 업데이트입니다.
압축 내부 폴더 구조를 유지해 기존 Solar-Homepage 폴더에 복사하세요.
먼저 기존 파일과 uploads 폴더를 백업하세요.

[새로 추가하는 파일 1개]
server/module-pdf-parser.js

[기존 파일 덮어쓰기 5개]
server/module-pdf.js
server/module-catalog.js
private/reg-module.html
public/js/reg-module.js
public/css/reg-module.css

[설명서 업데이트]
docs/module-registration.md

server/module-pdf-parser.js를 반드시 추가하세요. 누락 시 서버가 실행되지 않습니다.
reg-module.html은 private 폴더에 둡니다. public으로 옮기지 마세요.
.env, package.json, package-lock.json, 기존 모듈 JSON과 uploads 폴더는 변경하지 마세요.
추가 npm 패키지나 OCR 도구는 필요 없습니다. 기존 Poppler 설치는 유지하세요.

[Windows 로컬 적용 순서]
1. 실행 중인 서버의 PowerShell에서 Ctrl+C로 종료합니다.
2. 이 ZIP의 파일을 프로젝트 폴더 구조대로 복사합니다.
3. 같은 PowerShell 창에서 npm.cmd start로 재실행합니다.
4. 브라우저에서 Ctrl+F5로 새로고침한 뒤 관리자 로그인합니다.
5. 태양광 모듈 등록에서 PDF와 사양표 페이지(검증 원본은 2페이지)를 선택합니다.
6. 분석 후 '등록할 모델 선택'에서 모델을 고르고 추출값을 확인합니다.
7. 검토 완료 체크 후 등록합니다.

[자동 추출 검증]
LONGi 5모델, Qcells 2모델, Canadian Solar 7모델, TW Solar 5모델: 총 19모델.
STC와 BNPI를 분리하고 NOCT/NMOT 및 양면 발전 증가율은 참고로만 표시합니다.
BNPI가 없는 사양서는 값을 추정하지 않습니다. Canadian Solar 같은 양면 제품은
해당 기준의 추가 사양을 확인해야 합니다. 단면 확인 제품만 STC 값 사용 버튼을 누르세요.
Qcells 공통 제품군명은 정격 출력을 붙여 구분하므로 실제 라벨 모델명을 확인하세요.
TW Isc 온도계수 음수 부호는 원본대로 유지하고 경고하며 보수적인 전류 보정을 적용합니다.
이미지형 PDF는 OCR을 사용하지 않으므로 직접 입력합니다.
다른 사양서 형식은 인식이 제한될 수 있으므로 원본과 대조해야 합니다.

검증: 파서 회귀 검사 6개, 등록 API 검사 8개, 기존 계산기 검사 8개 통과.
기존 등록 UI 및 실제 Qcells 원본의 모델 선택/전환/등록 브라우저 검증 통과.
