﻿태양광 모듈 등록 업데이트 — 텍스트 PDF 전용, OCR 없음

기존 프로젝트의 폴더 구조에 맞춰 적용하세요.

신규 파일 6개:
private/reg-module.html
public/css/reg-module.css
public/js/reg-module.js
server/module-catalog.js
server/module-pdf.js
server/modules.js

덮어쓸 기존 파일 6개 (먼저 백업):
public/admin.html
public/admin-notices.html
public/admin-downloads.html
server/admin.js
server/calculator.js
server/calculator-engine.js

설치 안내: docs/module-registration.md
private 폴더가 없으면 생성하세요. reg-module.html을 public에 넣지 마세요.
.env, package.json, package-lock.json, 기존 모듈 JSON과 uploads 폴더는 보존하세요.
로컬 PC에 Node.js 24와 Poppler가 필요합니다.
Node 서버 재시작 후 관리자 계정으로 다시 로그인하세요. 관리자 로그인에는 기존 DB 및 계정 설정이 필요합니다.
