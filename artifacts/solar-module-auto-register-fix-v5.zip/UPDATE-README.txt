﻿태양광 모듈 등록 v5 — 조건 자동 판정 / 등록 불가 사유 표시

기존 모듈 등록 기능 v1~v4에 적용하는 누적 업데이트입니다.
서버 종료(Ctrl+C) -> 백업 -> 폴더 구조대로 파일 복사 -> npm.cmd start -> 브라우저 Ctrl+F5.

[추가/덮어쓸 파일 — 모두 적용]
server/module-pdf-parser.js (없으면 추가)
server/module-pdf.js
server/module-catalog.js
server/modules.js
server/calculator-engine.js
private/reg-module.html
public/js/reg-module.js
public/css/reg-module.css
public/js/calculator.js
public/calculator.html
설명서: docs/module-registration.md

.env, 기존 모듈 JSON, uploads, package.json, package-lock.json은 보존하세요.
추가 npm 패키지/OCR 설치 없이 기존 Poppler를 사용합니다.
이번 버전은 HTML/JS와 서버를 함께 바꿔야 합니다. 구버전 혼용은 등록 실패의 원인입니다.

[등록 순서]
PDF 선택 -> 사양표 페이지 분석 -> 등록할 모델 선택 -> 추출된 사양 확인 -> 등록.
제품 유형/근거 페이지/동의/검토 체크 등 조건 선택을 없앴습니다.
적용 기준은 읽기 전용 설명이며 선택할 필요가 없습니다.
실제 BNPI가 있으면 우선 사용하고, 없으면 확인된 제조사 발전 증가율 10% 표를 자동 적용합니다.
10% 대체는 BNPI와 다르며 고정 시나리오라는 계산기 안내를 유지합니다.

[등록 불가]
등록 버튼 바로 아래에 단면 제품/양면 여부 미확인/필수 사양 부족/중복/미선택 등의 이유를 표시합니다.
확인 불가능한 표나 이미지 PDF는 체크박스로 임의 승인할 수 없습니다.
서버가 저장된 PDF 분석 결과와 선택 모델을 다시 확인합니다.
양면 적용값은 PDF 원본 모델에서 자동 입력하며 수정할 수 없습니다.
기본 정보/STC/온도/퓨즈 수치의 유효성 검사는 유지합니다.
등록 클릭 전에 원본과 사양을 확인하세요. 기존 모듈은 자동 변경하지 않습니다.

[빙글 도는 커서 개선]
입력 부족으로 비활성화된 버튼은 금지 커서로 표시합니다.
실제 요청 중에만 진행 커서와 등록 중 문구를 표시합니다.
등록 응답 20초 / PDF 분석 90초 대기 후 상태를 해제하고 오류를 표시합니다.
등록 시간 초과 시 서버에 이미 반영되었을 수 있으니 다시 누르기 전에 목록을 확인하세요.

[검증]
파서 회귀 8개, 등록 API 9개 통과.
실제 Qcells/Canadian Solar 영문 PDF의 추가 조건 선택 없는 등록 및 계산 통과.
브라우저에서 누락 필드명/비활성 커서/중복 차단/모바일/서버 무응답 시간 제한 후 복구 확인.
