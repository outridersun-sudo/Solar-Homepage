'use strict';
// Download pinned official models through curl's normal proxy and TLS verification.
const {execFileSync}=require('node:child_process');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const directory=path.resolve(__dirname,'../.cache/solar-ocr');
const hashes={eng:'7d4322bd2a7749724879683fc3912cb542f19906c83bcc1a52132556427170b2',kor:'6b85e11d9bbf07863b97b3523b1b112844c43e713df8b66418a081fd1060b3b2'};
execFileSync(process.env.MODULE_TESSERACT_BIN || 'tesseract',['--version'],{stdio:'ignore'});
fs.mkdirSync(directory,{recursive:true});
for(const [language,hash]of Object.entries(hashes)){
 const filename=path.join(directory,language+'.traineddata');
 const verified=()=>fs.existsSync(filename)&&crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex')===hash;
 if(!verified()){
  const temporary=filename+'.'+crypto.randomUUID()+'.tmp';
  try{
   execFileSync('curl',['--fail','--location','--retry','2','--max-time','90','https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/4.1.0/'+language+'.traineddata','--output',temporary],{stdio:'inherit'});
   if(crypto.createHash('sha256').update(fs.readFileSync(temporary)).digest('hex')!==hash)throw Error('OCR model checksum mismatch: '+language);
   fs.renameSync(temporary,filename);
  }finally{fs.rmSync(temporary,{force:true});}
 }
 console.log('Verified OCR model: '+language);
}
execFileSync(process.env.MODULE_TESSERACT_BIN || 'tesseract',['--tessdata-dir',directory,'--list-langs'],{stdio:'inherit'});
