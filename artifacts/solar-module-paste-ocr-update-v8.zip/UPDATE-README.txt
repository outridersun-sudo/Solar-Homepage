Solar Homepage v8 — 이미지 복사/붙여넣기 + PDF 통합 분석

적용 대상: v5 전체 ZIP + v6 추출기 패치 적용 상태, 또는 v7 적용 상태.
누적 수정 파일만 포함합니다. 내부 경로대로 저장소 루트에 덮어쓰세요.
.env, 기존 업로드, catalog.json 및 node_modules는 포함하지 않습니다.

서버 준비 (한 번):
1. Tesseract 5와 curl이 필요합니다. Debian/Ubuntu에 없으면:
   sudo apt-get install -y tesseract-ocr curl
2. 저장소 루트에서 node scripts/setup-module-ocr.js 실행
   공식 kor/eng 모델을 .cache/solar-ocr에 다운로드하며 고정 SHA-256을 검증합니다.
   배포 시 이 모델 디렉터리를 유지하거나 설치 명령을 다시 실행하세요.
3. 서버를 재시작하고 등록 화면을 새로고침합니다.
별도 설치 경로는 MODULE_TESSERACT_BIN / MODULE_OCR_DATA_DIR로 지정할 수 있습니다.

사용법:
- 보완 사양 이미지를 복사하고 이미지 영역을 클릭해 Ctrl+V / Cmd+V로 붙여넣습니다.
- 이미지 파일 선택 창은 제거했습니다. PDF만 파일로 선택합니다.
- PDF + 이미지 함께 분석을 누릅니다. OCR 누락값을 PDF와 합쳐 필수 항목에 채웁니다.
- 온도계수/정격/양면 사양 등에 PDF 또는 이미지 OCR 출처가 표시됩니다.
- 이미지와 PDF의 값 충돌은 알려주고, 이미지 간 충돌값은 자동으로 선택하지 않습니다.
- OCR 적용값은 원본 근거와 검토 완료를 확인한 뒤 등록하며 직접 수정할 수 있습니다.
- 이미지 추가/제거 후에는 함께 분석을 다시 실행해야 합니다.

제한: 최대 3개 이미지/각 10MB. OCR은 읽기 가능한 표의 명확한 값만 적용합니다.
모델을 구분할 수 없는 다중 모델 전기표와 읽지 못한 값은 직접 확인이 필요합니다.
기존 단면 제품/중복/수치 일관성 검사와 관리자 인증/CSRF/세션별 이미지 보호를 유지합니다.

검증 명령:
node --test test/module-image-ocr.test.js test/module-review.test.js
node test/module-review-ui.cjs
node --test --test-isolation=none test/calculator.test.js
node test/calculator-ui.cjs
실제 클립보드 붙여넣기 및 Tesseract OCR을 검증합니다. UI 테스트에는 환경 제공 Playwright/Chromium이 필요합니다.
계산기 UI 테스트 실행 시 3000 포트를 비워 두세요.

원복: 적용 전에 교체 대상 파일을 백업하고 필요하면 복원한 뒤 서버를 재시작하세요.
사용자 업로드나 카탈로그는 삭제하지 마세요. SHA256SUMS.txt로 파일 무결성을 확인할 수 있습니다.
