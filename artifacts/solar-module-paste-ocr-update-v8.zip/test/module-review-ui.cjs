'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const {chromium}=require('playwright');
const {textPDF,testApp}=require('./helpers/module-fixtures.cjs');
(async()=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'solar-review-ui-'));process.env.MODULE_DATA_DIR=dir;
 const {app,password}=testApp();let browser;
 const server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s));});
 const base='http://127.0.0.1:'+server.address().port;
 try {
  browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
  const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  const login=await page.request.post(base+'/api/admin/login',{headers:{Origin:base},data:{username:process.env.ADMIN_USERNAME,password}});assert.equal(login.status(),200);
  await page.goto(base+'/reg-module.html');await page.waitForSelector('#management:visible');
  // Use the real browser clipboard and actual Tesseract, not a mocked analysis response.
  await page.context().grantPermissions(['clipboard-read','clipboard-write'],{origin:base});
  const source=await browser.newPage({viewport:{width:1500,height:1300}});
  await source.setContent('<div style="font:32px Arial;line-height:1.8;padding:32px;background:white;color:black">온도 특성 / Temperature coefficients<br>Voc 온도계수 (Voc) -0.25 %/C<br>Isc 온도계수 (Isc) +0.04 %/C<br>Pmax 온도계수 (Pmax) -0.29 %/C<br>Maximum system voltage 1500 V<br>Maximum series fuse 30 A<br>BNPI<br>Rated power (Pmax) 700 W<br>Open circuit voltage (Voc) 50 V<br>Maximum power voltage (Vmp) 40 V<br>Short circuit current (Isc) 18.5 A<br>Maximum power current (Imp) 17.5 A</div>');
  const image=await source.screenshot();await source.close();
  await page.evaluate(async data=>{
    const binary=atob(data),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
    await navigator.clipboard.write([new ClipboardItem({'image/png':new Blob([bytes],{type:'image/png'})})]);
  },image.toString('base64'));
  await page.click('#image-paste');await page.keyboard.press('Control+V');await page.waitForSelector('#supplement-previews img');
  assert.equal(await page.locator('#supplement-previews img').count(),1);
  // PDF has none of the five supplementary shared ratings: they must come from OCR.
  const omit=['Temperature coefficient','Maximum system voltage','Maximum series fuse'];
  await page.setInputFiles('#pdf-file',{name:'spec.pdf',mimeType:'application/pdf',buffer:textPDF([],omit)});
  assert.equal(await page.locator('#supplement-previews img').count(),1);
  assert.equal(await page.locator('input[type=file]').count(),1,'Only PDF uses a file chooser');
  await page.click('#analyze');await page.waitForSelector('#review:visible');await page.waitForFunction(()=>!document.querySelector('#analyze').disabled,null,{timeout:120000});
  assert.equal(await page.inputValue('#p'),'650');
  for(const [id,value]of Object.entries({betaVoc:-.25,alphaIsc:.04,gammaPower:-.29,maxV:1500,maxSeriesFuse:30,bnpi:700,bnpiVoc:50,bnpiVmp:40,bnpiIsc:18.5,bnpiImp:17.5})){
    assert.equal(Number(await page.inputValue('#'+id)),value,id+' must be automatically filled from OCR');
    assert.match(await page.locator('#'+id).locator('..').locator('..').innerText(),/이미지 1 OCR/);
  }
  assert.equal(await page.locator('#manual-review').isChecked(),true);
  assert.equal(await page.locator('#save').isDisabled(),true);
  // A manual correction after analysis must remain editable and persist.
  await page.fill('#bnpi','704');await page.fill('#bnpiImp','17.6');
  await page.fill('#evidence-text','PDF 1페이지 및 제조사 보완 이미지: 양면 BNPI 후면 일사 13.5% 기준 확인');
  assert.equal(await page.locator('#save').isDisabled(),true);
  await page.check('#review-confirmed');assert.equal(await page.locator('#save').isEnabled(),true);
  await page.setViewportSize({width:390,height:844});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  const response=page.waitForResponse(r=>r.url()===base+'/api/admin/modules' && r.request().method()==='POST');await page.click('#save');
  const saved=await response;assert.equal(saved.status(),201);assert.equal((await saved.json()).row.module.bnpi,704);
  await page.waitForSelector('#review',{state:'hidden'});assert.deepEqual(errors,[]);
  const rows=JSON.parse(await fs.readFile(path.join(dir,'catalog.json'),'utf8'));assert.equal(rows[0].supplements.length,1);
  console.log('PASS: real clipboard image paste before PDF, actual Korean/English OCR, PDF + image merged required fields and source badges, editable corrections, review gating, mobile layout and persistence');
 } finally {if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));await fs.rm(dir,{recursive:true,force:true});}
})().catch(error=>{console.error(error);process.exitCode=1;});
