'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const {textPDF,testApp,moduleBody}=require('./helpers/module-fixtures.cjs');
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAIAAAAlC+aJAAAAYElEQVR4nO3PQQ0AIBDAMMC/50MEj4ZkVbDtmVk/OzrgVQNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgPaBXKqA31N0fbGAAAAAElFTkSuQmCC','base64');
test('module review: actual PDF, protected supplementary images, manual corrections, catalog persistence', {timeout:120000},async t=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'solar-review-'));process.env.MODULE_DATA_DIR=dir;
 const {app,password}=testApp();
 const server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s));});
 const base='http://127.0.0.1:'+server.address().port;
 let cookie='',csrf='';
 const request=(url,options={})=>fetch(base+url,{...options,headers:{Origin:base,Cookie:cookie,'X-CSRF-Token':csrf,...(options.body && !(options.body instanceof FormData)?{'Content-Type':'application/json'}:{}),...options.headers},redirect:'manual'});
 const upload=async(buffer=textPDF())=>{const form=new FormData();form.set('file',new Blob([buffer]),'spec.pdf');form.set('page','1');const r=await request('/api/admin/modules/import',{method:'POST',body:form});assert.equal(r.status,200);return r.json();};
 const images=(id,buffer=png,count=1)=>{const form=new FormData();for(let i=0;i<count;i++)form.append('images',new Blob([buffer],{type:'image/png'}),'supplement.png');return request('/api/admin/modules/import/'+id+'/images',{method:'POST',body:form});};
 const save=body=>request('/api/admin/modules',{method:'POST',body:JSON.stringify(body)});
 try {
  const login=await request('/api/admin/login',{method:'POST',body:JSON.stringify({username:process.env.ADMIN_USERNAME,password})});assert.equal(login.status,200);cookie=login.headers.getSetCookie()[0].split(';')[0];csrf=(await login.json()).csrf;
  let data=await upload();assert.equal(data.fields.p,650);assert.equal(data.pages,1);
  const body={...moduleBody,importId:data.importId,modelId:data.models[0].id,manualReview:true,bifacialStatus:'bifacial',bifacialEvidence:'Page 1 and supplementary manufacturer specification: bifacial BNPI 13.5%',evidencePage:1,rearSpecMode:'bnpi',reviewed:true,bnpi:700,bnpiVoc:50,bnpiVmp:40,bnpiIsc:18.5,bnpiImp:17.5};
  await t.test('unknown/missing rear values cannot register without explicit evidence',async()=>{
   assert.equal((await save({...body,manualReview:false})).status,422);
   assert.equal((await save({...body,bifacialEvidence:''})).status,422);
   assert.equal((await save({...body,evidencePage:2})).status,422);
   assert.equal((await save({...body,reviewed:false})).status,400);
   assert.equal((await save({...body,bnpiImp:100})).status,422);
  });
  let image;
  await t.test('image signatures, authorization, CSRF and count limits',async()=>{
   assert.equal((await images(data.importId,Buffer.from('<svg></svg>'))).status,400);
   const r=await images(data.importId);assert.equal(r.status,200);image=(await r.json()).images[0];
   assert.equal((await request(image.url,{headers:{Cookie:''}})).status,401);
   const read=await request(image.url);assert.equal(read.status,200);assert.equal(read.headers.get('content-type'),'image/png');assert.deepEqual(Buffer.from(await read.arrayBuffer()),png);
   assert.equal((await request('/api/admin/modules/import/'+data.importId+'/images',{method:'POST',headers:{'X-CSRF-Token':''}})).status,403);
   assert.equal((await images(data.importId,png,3)).status,400);
   assert.equal((await images(data.importId,png,2)).status,200);
   assert.equal((await images(data.importId)).status,400);
  });
  await t.test('new images invalidate stale analysis until PDF and images are analyzed together',async()=>{assert.equal((await save(body)).status,422);});
  await t.test('re-extraction retains supplementary references',async()=>{
   const r=await request('/api/admin/modules/import/'+data.importId+'/extract',{method:'POST',body:'{"page":1}'});assert.equal(r.status,200);assert.equal((await r.json()).images.length,3);
  });
  await t.test('corrected values and evidence persist and reach calculator catalog',async()=>{
   const r=await save(body);assert.equal(r.status,201,JSON.stringify(await r.clone().json()));
   const catalog=JSON.parse(await fs.readFile(path.join(dir,'catalog.json'),'utf8'));
   assert.equal(catalog[0].module.bnpi,700);assert.equal(catalog[0].module.bnpiImp,17.5);assert.equal(catalog[0].supplements.length,3);assert.match(catalog[0].evidence.text,/supplementary/);
   for(const image of catalog[0].supplements)assert.deepEqual(await fs.readFile(path.join(dir,image.storedName)),png);
   const c=await request('/api/calculator/catalog');assert.equal((await c.json()).modules['Test Solar']['TEST Series'][0].bnpi,700);
   const calculation=await request('/api/calculator/calculate',{method:'POST',body:JSON.stringify({manufacturer:'Test Solar',series:'TEST Series',model:'TEST-650',basis:'capacity',priority:'desc',requestedKWp:10,moduleCount:15,ratio:1,tolerance:.1,voltage:380,kva350:350,pf350:1,minTemperature:-20,maxCellTemperature:70,vmpCoefficient:-.25,rearIrradiance:13.5,vocMargin:5,iscFactor:1.25,azimuth:180,tilt:30})});
   assert.equal(calculation.status,200);assert.equal((await calculation.json()).input.module.bnpi,700);
   assert.equal((await request(image.url)).status,410);assert.deepEqual(await fs.readdir(path.join(dir,'imports')),[]);
  });
  await t.test('automatic BNPI corrections are not overwritten by extracted values',async()=>{
   const extra=['BNPI','Rated power (Pmax) 700 W','Open circuit voltage (Voc) 50 V','Maximum power voltage (Vmp) 40 V','Short circuit current (Isc) 18.5 A','Maximum power current (Imp) 17.5 A'];
   const automatic=await upload(textPDF(extra));assert.equal(automatic.models[0].registration.allowed,true);
   const r=await save({...body,manualReview:false,name:'TEST-650-EDITED',importId:automatic.importId,modelId:automatic.models[0].id,bnpi:704,bnpiImp:17.6});assert.equal(r.status,201);
   assert.equal((await r.json()).row.module.bnpi,704);
  });
  await t.test('unrecognized model supports complete manual entry',async()=>{
   const unknown=await upload(Buffer.from(textPDF().toString().replace('Model:','Other:')));assert.equal(unknown.models.length,0);
   const r=await save({...body,name:'MANUAL-650',importId:unknown.importId,modelId:undefined});assert.equal(r.status,201);
  });
  await t.test('image removal invalidates analysis and removes its private file',async()=>{
   const another=await upload();const uploaded=await images(another.importId);const image=(await uploaded.json()).images[0];
   assert.equal((await request(image.url,{method:'DELETE'})).status,200);
   assert.equal((await request(image.url)).status,404);
   assert.equal((await save({...body,name:'REMOVED',importId:another.importId})).status,422);
   await request('/api/admin/modules/import/'+another.importId,{method:'DELETE'});
  });
  await t.test('cancel removes PDF and images',async()=>{
   const another=await upload();assert.equal((await images(another.importId)).status,200);
   assert.equal((await request('/api/admin/modules/import/'+another.importId,{method:'DELETE'})).status,200);assert.deepEqual(await fs.readdir(path.join(dir,'imports')),[]);
  });
 } finally {await new Promise(resolve=>server.close(resolve));await fs.rm(dir,{recursive:true,force:true});}
});
test('v6 Qcells ML-G3R.14+ extraction remains model-aware',()=>{
 const {analyze}=require('../server/module-pdf-parser');
 const data=analyze('Q.TRON ML-G3R.14+ / BFG\n전력 등급 650\n정격 출력 650 700\n개방 전압 Voc 50 50\n최대 출력 전압 Vmp 40 40\n단락 전류 Isc 17 18.5\n최대 출력 전류 Imp 16.25 17.5\n모듈 효율 23\n정상 작동 조건');
 assert.equal(data.profile,'qcells-ml-g3r14');assert.equal(data.models.length,1);assert.equal(data.models[0].fields.p,650);assert.equal(data.models[0].fields.bnpi,700);assert.equal(data.models[0].registration.allowed,true);
});
