'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {imageAnalysis,combine}=require('../server/module-image-ocr');
const base=(models=[],fields={})=>({text:'STC',fields,models,method:'text',page:1,pages:1});
const model=(name,fields={})=>({id:name,fields:{name,...fields},registration:{allowed:false},warnings:[]});
test('OCR reads explicit temperature percentages despite a misread symbol annotation',()=>{
 const data=imageAnalysis('Temperature coefficients\nVoc 온도계수 (Voc) -0.25 %/C\nIsc 온도계수 (160) +0.04 %/C\nPmax 온도계수 (Pmax) -0.29 %/C');
 assert.equal(data.fields.betaVoc,-.25);assert.equal(data.fields.alphaIsc,.04);assert.equal(data.fields.gammaPower,-.29);
});
test('single model receives missing image fields, PDF fields keep priority and conflicts are visible',()=>{
 const r=combine(base([model('A',{maxV:1000})]),[{filename:'copy.png',text:'Temperature coefficient Voc -0.25 %/C\nMaximum system voltage 1500 V'}]);
 assert.equal(r.fields.betaVoc,-.25);assert.equal(r.fieldSources.betaVoc,'이미지 1 OCR');assert.equal(r.fields.maxV,1000);assert.match(r.conflicts.join(' '),/maxV/);
});
test('conflicting image values remain empty rather than choosing an arbitrary image',()=>{
 const r=combine(base([model('A')]),[{text:'Temperature coefficient Voc -0.25 %/C'},{text:'Temperature coefficient Voc -0.35 %/C'}]);
 assert.equal(r.fields.betaVoc,undefined);assert.match(r.warning,/이미지 간/);
});
test('unnamed electrical values are never spread across multiple PDF models',()=>{
 const r=combine(base([model('A'),model('B')]),[{text:'Rated power 650 W\nTemperature coefficient Voc -0.25 %/C'}]);
 for(const m of r.models){assert.equal(m.fields.p,undefined);assert.equal(m.fields.betaVoc,-.25);}
 assert.equal(r.fields.p,undefined);
});
test('other model OCR cannot fill the selected PDF model',()=>{
 const text='Model: B\nRated power 650 W\nOpen circuit voltage 50 V\nMaximum power voltage 40 V\nShort circuit current 17 A\nMaximum power current 16.25 A\nTemperature coefficient Voc -0.25 %/C';
 const r=combine(base([model('A')]),[{text}]);assert.equal(r.fields.betaVoc,undefined);assert.match(r.warning,/모델과 일치하지/);
});
test('NOCT values and percentages without temperature meaning are not invented as STC coefficients',()=>{
 const r=imageAnalysis('NOCT\nRated power 450 W\nVoc 42 V\nPower gain 10%');assert.equal(r.fields.p,undefined);assert.equal(r.fields.gammaPower,undefined);
});

test('a named partial image only fills its own model, never other models or common fields',()=>{
 const r=combine(base([model('A'),model('B')]),[{text:'Model: B\nTemperature coefficient Voc -0.25 %/C'}]);
 assert.equal(r.models[0].fields.betaVoc,undefined);assert.equal(r.models[1].fields.betaVoc,-.25);assert.equal(r.fields.betaVoc,undefined);
});

test('missing OCR executable reports a concrete setup prerequisite',async()=>{
 const previous=process.env.MODULE_TESSERACT_BIN;process.env.MODULE_TESSERACT_BIN='/nonexistent/solar-test-tesseract';
 try{await assert.rejects(require('../server/module-image-ocr').recognize('/unused'),error=>error.status===503 && /setup-module-ocr/.test(error.message));}
 finally{if(previous===undefined)delete process.env.MODULE_TESSERACT_BIN;else process.env.MODULE_TESSERACT_BIN=previous;}
});
