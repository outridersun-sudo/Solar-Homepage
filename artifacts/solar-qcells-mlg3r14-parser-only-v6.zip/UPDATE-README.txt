﻿Qcells ML-G3R.14+ / BFG 추출 규칙 추가 — 서버 파일 1개 교체

기존 v5 모듈 등록 기능 기준의 내부 추출 규칙 패치입니다.
HTML/CSS/화면 JavaScript/계산기/기존 모듈 데이터는 변경하지 않습니다.

[교체 파일]
server/module-pdf-parser.js

[Windows 로컬 적용]
1. 실행 중인 서버 PowerShell에서 Ctrl+C.
2. 기존 server/module-pdf-parser.js를 백업.
3. ZIP 안의 server/module-pdf-parser.js를 같은 경로에 덮어쓰기.
4. 기존 Poppler PATH 설정이 유지된 터미널에서 npm.cmd start.
5. 관리자 화면에서 원본 PDF의 2페이지를 분석.
6. 635/640/645/650/655W 중 모델을 선택하고 추출값을 확인한 뒤 등록.

프로젝트 전체를 새 ZIP으로 교체하지 마세요. 파일 1개만 교체합니다.
.env, uploads, public, private 폴더는 변경하지 않습니다.
기존과 동일한 제조사/모델명은 중복으로 등록되지 않습니다.
새 규칙은 실제 BNPI를 사용하며 10% 대체 모드로 처리하지 않습니다.

[검증]
9개 파서 회귀 테스트 통과.
원본 ML-G3R PDF의 5개 모델 선택/수치 입력/등록 브라우저 검증 통과.
기존 Qcells XL, LONGi, Canadian Solar, TW의 추출 결과 변경 전후 동일 확인.
HTML/CSS/화면 JS 변경 전후 해시 동일 확인.

[640W 추출 예]
제조사 Qcells / 시리즈 Q.TRON ML-G3R.14+ / BFG
STC: 640W, Voc 49.75V, Vmp 41.38V, Isc 16.33A, Imp 15.47A, 효율 23.7%
BNPI: 706.8W, Voc 49.75V, Vmp 41.38V, Isc 18.03A, Imp 17.08A
공통: 최대 1500V, 퓨즈 30A, Voc -0.24 / Isc +0.046 / Pmax -0.28 %/℃
