Solar Homepage v7 — PDF 보완 이미지 및 적용값 직접 수정

적용 전제: v5 전체 ZIP 적용 후 v6 추출기 패치를 적용한 상태.
ZIP 내부의 경로 그대로 저장소 루트에 덮어쓰고 Node.js 서버를 재시작하세요.
변경 파일만 포함합니다. v6 server/module-pdf-parser.js는 변경하지 않으며 포함하지 않습니다.
.env, 사용자 업로드 및 기존 catalog.json은 포함하거나 덮어쓰지 않습니다. 새 npm 의존성은 없습니다.

PDF 분석 후 미리보기 옆에서 적용 사양을 수정합니다. PNG/JPEG/WebP 보완 이미지를
PDF당 최대 3개(파일당 10MB) 업로드하고 원본을 대조할 수 있습니다. 이미지 OCR은 없습니다.
확인 필요 항목은 직접 입력 모드를 선택하고 근거 페이지·원본 근거·검토 완료를 입력하세요.
BNPI 및 제조사 발전 증가율 10% 대체 기준을 구분하며 단면·중복·잘못된 수치는 차단합니다.
수정한 사양은 등록 및 계산기에서 그대로 사용합니다. 보완 이미지는 비공개 저장소에 보관됩니다.

검증 (Node.js 24 / Poppler / 환경 제공 Playwright 및 Chromium):
node --test test/module-review.test.js
node test/module-review-ui.cjs
node --test --test-isolation=none test/calculator.test.js
node test/calculator-ui.cjs
마지막 UI 테스트 실행 시 3000 포트를 비워 두세요. 테스트는 임시 데이터만 사용합니다.

원복: 덮어쓰기 전 대상 파일을 백업하고 필요 시 백업을 복원한 뒤 서버 재시작.
카탈로그와 이미지 데이터는 삭제하지 마세요. SHA256SUMS.txt로 압축 내 파일 무결성을 확인할 수 있습니다.
