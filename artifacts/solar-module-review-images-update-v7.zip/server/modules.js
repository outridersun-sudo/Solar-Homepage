'use strict';
const multer = require('multer');
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');
const catalog = require('./module-catalog');
const pdf = require('./module-pdf');
const directory = path.join(catalog.directory, 'imports');
const imports = new Map();
const imageUpload = multer({storage:multer.diskStorage({destination:(req,file,done)=>done(null,directory),filename:(req,file,done)=>done(null,crypto.randomUUID()+'.image')}),limits:{files:3,fileSize:10*1024*1024,fields:0,parts:3}}).array('images',3);
async function removeImport(item) {
  await Promise.all([item.path,...(item.images || []).map(image=>image.path)].map(filename=>fs.rm(filename,{force:true})));
}

const upload = multer({storage:multer.diskStorage({
  destination:(req,file,done) => done(null,directory),
  filename:(req,file,done) => done(null,crypto.randomUUID()+'.pdf')
}), limits:{files:1,fileSize:20*1024*1024,fields:1,parts:2,fieldSize:20}}).single('file');
function owned(req) {
  const item = imports.get(req.params.id || req.body?.importId);
  if (!item || item.owner !== req.adminSession.id || item.expires < Date.now()) throw Object.assign(new Error('PDF 업로드가 만료되었습니다. 파일을 다시 선택하세요.'),{status:410});
  return item;
}
function originalName(value) {
  const decoded = Buffer.from(value,'latin1').toString('utf8');
  if (!decoded.includes('\uFFFD')) value = decoded;
  return value.replaceAll('\\','/').split('/').pop().replace(/[\x00-\x1f\x7f]/g,'').slice(0,200);
}
module.exports = function registerModules(app) {
  const cleanup = setInterval(() => {
    for (const [id,item] of imports) if (item.expires < Date.now() && !item.busy) {
      imports.delete(id); removeImport(item).catch(() => {});
    }
  },60000);
  cleanup.unref();
  app.get('/api/admin/modules', (req,res,next) => { try {res.json({rows:catalog.list()});} catch(error) {next(error);} });
  app.post('/api/admin/modules/import', async (req,res,next) => {
    try {
      if (imports.size >= 30) return res.status(429).json({message:'업로드가 많습니다. 기존 작업을 완료한 뒤 시도하세요.'});
      await fs.mkdir(directory,{recursive:true});
      upload(req,res,async error => {
        try {
          if (error) throw Object.assign(new Error('20MB 이하의 PDF 파일 하나를 선택하세요.'),{status:400});
          if (!req.file || !/\.pdf$/i.test(req.file.originalname)) throw Object.assign(new Error('PDF 파일을 선택하세요.'),{status:400});
          const handle = await fs.open(req.file.path,'r');
          const signature = Buffer.alloc(5);
          try {await handle.read(signature,0,5,0);} finally {await handle.close();}
          if (signature.toString() !== '%PDF-') throw Object.assign(new Error('유효한 PDF 파일이 아닙니다.'),{status:400});
          const id = crypto.randomUUID();
          const item = {id,path:req.file.path,filename:originalName(req.file.originalname),owner:req.adminSession.id,expires:Date.now()+3600000,busy:true};
          imports.set(id,item);
          // Keep the valid upload when extraction fails so another page can be tried.
          try {
            const result = await pdf.extract(item.path,Number(req.body.page || 1));
            item.pages=result.pages;item.analysis=result;
            res.json({...result,importId:id,filename:item.filename});
          } catch (failure) {
            res.status(failure.status || 500).json({message:failure.message,importId:id,filename:item.filename});
          } finally {item.busy=false;}
        } catch(failure) {
          if (req.file) await fs.rm(req.file.path,{force:true}).catch(()=>{});
          next(failure);
        }
      });
    } catch(error) {next(error);}
  });
  app.post('/api/admin/modules/import/:id/images', async (req,res,next) => {
    let item;
    try {
      item=owned(req);
      if(item.busy)return res.status(409).json({message:'분석이 끝난 뒤 이미지를 추가하세요.'});
      if((item.images || []).length>=3)return res.status(400).json({message:'보완 이미지는 최대 3개입니다.'});
      item.busy=true;
      await fs.mkdir(directory,{recursive:true});
      imageUpload(req,res,async error=>{
        try {
          if(error)throw Object.assign(new Error('이미지는 파일당 10MB 이하, 최대 3개입니다.'),{status:400});
          const files=req.files || [];
          if(!files.length || (item.images || []).length+files.length>3)throw Object.assign(new Error('보완 이미지는 총 1~3개를 선택하세요.'),{status:400});
          const {fileTypeFromBuffer}=await import('file-type');
          const images=[];
          for(const file of files){
            const buffer=await fs.readFile(file.path),type=await fileTypeFromBuffer(buffer);
            if(!type || !['image/png','image/jpeg','image/webp'].includes(type.mime))throw Object.assign(new Error('실제 PNG·JPEG·WebP 이미지만 업로드할 수 있습니다.'),{status:400});
            images.push({id:crypto.randomUUID(),path:file.path,filename:originalName(file.originalname),mime:type.mime,ext:type.ext});
          }
          item.images=[...(item.images || []),...images];
          res.json({images:item.images.map(({id,filename})=>({id,filename,url:'/api/admin/modules/import/'+item.id+'/images/'+id}))});
        } catch(failure){
          await Promise.all((req.files || []).map(file=>fs.rm(file.path,{force:true})));
          next(failure);
        } finally {item.busy=false;}
      });
    }catch(error){if(item)item.busy=false;next(error);}
  });
  app.get('/api/admin/modules/import/:id/images/:imageId', (req,res,next)=>{
    try {
      const item=owned(req),image=item.images?.find(image=>image.id===req.params.imageId);
      if(!image)return res.status(404).json({message:'이미지가 없습니다.'});
      res.set('X-Content-Type-Options','nosniff').type(image.mime).sendFile(image.path);
    }catch(error){next(error);}
  });
  app.post('/api/admin/modules/import/:id/extract', async (req,res,next) => {
    let item, acquired=false;
    try {
      item = owned(req);
      if (item.busy) return res.status(409).json({message:'분석 중입니다. 잠시 기다려 주세요.'});
      item.busy=true; acquired=true;
      const result=await pdf.extract(item.path,Number(req.body.page));item.pages=result.pages;item.analysis=result;
      res.json({...result,importId:item.id,filename:item.filename,images:(item.images || []).map(({id,filename})=>({id,filename,url:'/api/admin/modules/import/'+item.id+'/images/'+id}))});
    } catch(error) {next(error);} finally {if(acquired) item.busy=false;}
  });
  app.delete('/api/admin/modules/import/:id', async (req,res,next) => {
    try {
      const item=owned(req);
      if(item.busy) return res.status(409).json({message:'분석이 끝난 뒤 취소하세요.'});
      imports.delete(item.id); await removeImport(item); res.json({ok:true});
    } catch(error) {next(error);}
  });
  app.post('/api/admin/modules', async (req,res,next) => {
    try {
      const item=owned(req);
      if (item.busy) return res.status(409).json({message:'분석이 끝난 뒤 등록하세요.'});
      if(!item.pages)return res.status(422).json({code:'BIFACIAL_UNCONFIRMED',message:'양면 여부 미확인: PDF 페이지를 정상적으로 분석한 뒤 확인 근거를 입력하세요.'});
      const candidate=item.analysis?.models?.find(model=>model.id===req.body?.modelId);
      if(candidate?.registration?.code==='MONOFACIAL' || /monofacial|단면\s*(?:모듈|제품)/i.test(item.analysis?.text || ''))return res.status(422).json({code:'MONOFACIAL',message:'단면 제품은 등록할 수 없습니다.'});
      const manual=req.body?.manualReview===true;
      if(!manual && !candidate?.registration?.allowed)return res.status(422).json({code:'BIFACIAL_UNCONFIRMED',message:'확인 필요 항목을 직접 입력하고 원본 검토를 완료하세요.'});
      const mode=manual?req.body.rearSpecMode:candidate.registration.mode;
      // Submitted electrical values are intentionally editable; validate all of them.
      const body={...req.body,rearSpecMode:mode};
      if(!manual)Object.assign(body,{bifacialStatus:'bifacial',evidencePage:item.analysis.page,bifacialEvidence:'PDF '+item.analysis.page+'페이지 / '+candidate.id+' 원본 대조',reviewed:true,substituteConfirmed:mode==='gain10'});
      catalog.validate(body,item.pages);
      const sourceId=crypto.randomUUID();
      const target=path.join(catalog.directory,sourceId+'.pdf');
      // Synchronous operations keep duplicate detection and import consumption together.
      require('node:fs').copyFileSync(item.path,target,require('node:fs').constants.COPYFILE_EXCL);
      let row;
      const imageTargets=[];
      try {
        const supplements=[];
        for(const image of item.images || []){
          const storedName=sourceId+'-'+image.id+'.'+image.ext;
          const destination=path.join(catalog.directory,storedName);
          require('node:fs').copyFileSync(image.path,destination,require('node:fs').constants.COPYFILE_EXCL);
          imageTargets.push(destination);supplements.push({filename:image.filename,storedName,mime:image.mime});
        }
        row=catalog.add(body,{id:sourceId,filename:item.filename,pages:item.pages,supplements});
      } catch(error) {
        for(const filename of [target,...imageTargets])require('node:fs').rmSync(filename,{force:true});
        throw error;
      }
      imports.delete(item.id);
      await removeImport(item).catch(()=>{});
      res.status(201).json({message:'모듈을 등록했습니다. 계산기를 새로 열면 선택할 수 있습니다.',row});
    } catch(error) {next(error);}
  });
  app.use('/api/admin/modules',(error,req,res,next) => {
    if (!error.status) return next(error);
    res.status(error.status).json({message:error.message,...(error.code?{code:error.code}:{})});
  });
};
