﻿태양광 모듈 등록 v4 — 발전 증가율 10% 대체 사양 사용

앞서 설치한 모듈 등록 기능 v1/v2/v3에 적용하는 누적 업데이트입니다.
현재 서버를 Ctrl+C로 종료하고 백업한 뒤 내부 폴더 구조대로 복사하세요.

[추가/덮어쓸 실행 파일]
server/module-pdf-parser.js (없으면 추가)
server/module-pdf.js
server/module-catalog.js
server/modules.js
server/calculator-engine.js
private/reg-module.html
public/js/reg-module.js
public/css/reg-module.css
public/js/calculator.js
public/calculator.html

[설명서]
docs/module-registration.md

계산 엔진과 계산기 화면 파일까지 모두 반영해야 합니다.
등록 화면 문구만 바꾸는 업데이트가 아닙니다.
.env, 기존 모듈 JSON, uploads, package.json, package-lock.json은 보존하세요.
추가 npm 패키지나 OCR 설치는 필요 없습니다. 기존 Poppler를 유지합니다.

[적용 후]
같은 PowerShell에서 npm.cmd start로 서버를 시작합니다.
브라우저 Ctrl+F5 후 관리자 로그인합니다.
PDF 사양표 페이지를 분석하고 모델을 선택합니다.
적용 기준에서 ‘대체 사양 — 제조사 발전 증가율 10% 표’를 선택합니다.
지원되는 표의 10% 값은 자동 입력됩니다. 원본과 대조하세요.
양면 제품 유형, 근거 PDF 페이지와 문구를 확인하고 대체 사용 동의 및 최종 검토를 선택해 등록합니다.

[계산 정책 — 반드시 확인]
실제 BNPI가 있으면 기존 BNPI 기준을 우선 사용하세요.
10% 발전 증가율은 후면 일사량 13.5%와 같은 항목이 아닙니다.
대체 모드는 제조사 10% 표의 출력/전압/전류를 고정 적용한 예비 시나리오입니다.
후면 일사율 입력을 비활성화하고 보간/외삽하지 않습니다.
온도와 Voc 여유/전류 계수는 기존 설계 모드를 따릅니다.
자료 재현 모드의 저온 Voc는 기존 정책대로 STC입니다. 용량/AC-DC 기준도 STC입니다.
실제 현장 발전량이나 최종 설계 승인 조건으로 간주하지 마세요.

대체 사양은 rearSpecMode=gain10으로 명시 저장합니다.
내부 bnpi* 키는 호환용 숫자 저장 칸으로 실제 BNPI라는 뜻이 아닙니다.
후면 일사량 근거는 null, 발전 증가율은 10으로 기록합니다.
계산 결과/설명/견적 연결과 등록 목록에서 대체 여부를 표시합니다.
단면 제품/양면 미확인/필수 사양 부족/대체 동의 없는 등록 차단은 유지합니다.
기존 등록 모듈은 자동 변경하지 않습니다.

[지원 추가]
Canadian Solar F67 영문 630~660W의 새 표 제목/전체 모델명/줄바꿈된 10% 행을 지원합니다.
한글판의 깨진 글자나 이미지형 PDF를 OCR로 복원하는 기능은 없습니다.

[검증]
파서 7개, 등록 API 9개, 기존 계산기 단위 테스트 8개 통과.
실제 F67 원본의 10% 대체 등록 및 계산기 동작, Qcells 원본 BNPI 등록,
기존 계산기 브라우저 회귀 테스트 통과.
후면 일사율 0/13.5/30 API 요청 모두 고정 10% 값 사용 확인.
