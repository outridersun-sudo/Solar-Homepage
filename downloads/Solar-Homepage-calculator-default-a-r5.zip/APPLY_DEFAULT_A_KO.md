# A안 기본 선택 적용 — r5

기존 변경 사항이 적용된 프로젝트에서 아래 2개 파일을 같은 경로로 덮어쓰세요.

- D:\Works\Solar-Homepage\public\calculator.html
- D:\Works\Solar-Homepage\public\js\calculator.js

최초 계산 시 A안이 기본 선택됩니다. A안이 없는 조건에서는 B안을 표시합니다.
사용자가 직접 선택한 안은 가능한 경우 이후 재계산에서도 유지합니다.
브라우저에서 Ctrl+Shift+R로 새로고침하세요.
